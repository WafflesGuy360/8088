x=msgbox("this malware is no joke"1,16"warning")
x=msgbox("fully running this program will take you to the BSOD"1,16"warning")
x=msgbox("i am not responsible for any damages"1,16"warning")